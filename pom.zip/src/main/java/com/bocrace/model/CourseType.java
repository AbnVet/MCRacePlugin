package com.bocrace.model;

public enum CourseType {
    SINGLEPLAYER,
    MULTIPLAYER
}
